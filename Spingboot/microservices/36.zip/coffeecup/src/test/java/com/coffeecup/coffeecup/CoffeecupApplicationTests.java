package com.coffeecup.coffeecup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeecupApplicationTests {

	@Test
	void contextLoads() {
	}

}
