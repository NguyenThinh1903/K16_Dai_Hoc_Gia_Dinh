package com.coffeecup.coffeecupadminsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeecupAdminSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
