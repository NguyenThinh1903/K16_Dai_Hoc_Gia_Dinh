from menu import StartMenu

def main():
    menu = StartMenu()
    menu.mainloop()

if __name__ == "__main__":
    main()