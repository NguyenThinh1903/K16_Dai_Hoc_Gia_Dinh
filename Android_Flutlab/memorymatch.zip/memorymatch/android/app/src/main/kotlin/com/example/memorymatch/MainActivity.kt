package com.example.memorymatch

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
