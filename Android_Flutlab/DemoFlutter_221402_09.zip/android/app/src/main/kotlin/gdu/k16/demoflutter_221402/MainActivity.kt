package gdu.k16.demoflutter_221402

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
